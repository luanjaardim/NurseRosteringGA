The XML files (.ros|.roster) for the instances and solutions can also be opened
using the RosterBooster program available at http://www.staffrostersolutions.com/downloads.php